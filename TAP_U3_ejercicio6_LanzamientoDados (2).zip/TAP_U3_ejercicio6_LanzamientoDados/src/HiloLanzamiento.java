
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alejandro
 */
public class HiloLanzamiento extends Thread {
    Ventana v;
    int dado1, dado2;
    int yoSoy;
    int suma, numMayor,ganador;
    public HiloLanzamiento (Ventana v, int tuEres){
        this.v = v;
        yoSoy = tuEres;
    }
    
    
    public void run(){
       // while(true){
            for (int i = 0; i <= 2; i++) {
                if(yoSoy==v.turno){
                    dado1 = (int)(Math.random()*5+1);
                    dado2 = (int)(Math.random()*5+1);
                    suma = dado1+ dado2;
                    v.suma=suma;
                    v.Gana=i;
                    switch (i){
                        case 0:
                            v.mostrarMensaje("Resultado dado 1: "+dado1+"\n"+"Resultado dado 2: "+dado2);
                            v.jTextPane1.setText(v.Buffer);
                            
                            break;
                        case 1:
                            v.mostrarMensaje("Resultado dado 1: "+dado1+"\n"+"Resultado dado 2: "+dado2);
                            v.jTextPane2.setText(v.Buffer);
                            break;
                        case 2:
                            v.mostrarMensaje("Resultado dado 1: "+dado1+"\n"+"Resultado dado 2: "+dado2);
                            v.jTextPane3.setText(v.Buffer);
                            break;
                    }                    
                }
                if(suma>numMayor){
                    numMayor=suma;
                    ganador=i+1;
                }
                suma=0;
            try {
                sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(HiloLanzamiento.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            v.ganador(ganador, numMayor);
            v.jLabel4.setText("Ganador: jugador "+ganador+" con "+numMayor);
            v.turno++; 
    }
    
}
